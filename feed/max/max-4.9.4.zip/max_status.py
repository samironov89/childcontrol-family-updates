# -*- coding: utf-8 -*-
"""ChildControl 4.7 (test only): read local status, optionally send it to MAX.

No changes to controller, tasks, time limits or passwords. No background activity,
no screenshots, no receive-commands loop and no token persistence.
"""
from __future__ import annotations

import argparse
import ctypes
from datetime import date
import getpass
import http.client
import json
import os
from pathlib import Path
import sqlite3
import sys

ROOT = Path(os.environ.get('ProgramData', r'C:\ProgramData')) / 'ChildControl'
SETTINGS = ROOT / 'family_settings.json'
DB = ROOT / 'usage.sqlite3'
ENFORCE = ROOT / 'enforcement.json'
MAX_HOST = 'platform-api2.max.ru'
PARENT_USER_ID = 137002909
EXPECTED_BOT_ID = 532313975


class ApiError(Exception):
    pass


def admin_required():
    if os.name != 'nt' or not ctypes.windll.shell32.IsUserAnAdmin():
        raise PermissionError('Запусти PowerShell от имени администратора.')


def api_request(token, method, path, payload=None):
    headers = {'Authorization': token, 'Accept': 'application/json',
               'User-Agent': 'ChildControl/4.7-test'}
    body = None
    if payload is not None:
        body = json.dumps(payload, ensure_ascii=False).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    connection = http.client.HTTPSConnection(MAX_HOST, timeout=25)
    try:
        connection.request(method, path, body=body, headers=headers)
        response = connection.getresponse()
        status = response.status
        raw = response.read(1024 * 1024)
    except (OSError, http.client.HTTPException) as e:
        raise ApiError('Не удалось связаться с MAX: {}'.format(type(e).__name__)) from None
    finally:
        connection.close()
    try:
        value = json.loads(raw.decode('utf-8'))
    except (ValueError, UnicodeError):
        value = {}
    if status < 200 or status >= 300:
        code = str(value.get('code', '')) if isinstance(value, dict) else ''
        # Do not leak token or server response body, which could contain request data.
        raise ApiError('MAX HTTP {} {}'.format(status, code))
    if not isinstance(value, dict):
        raise ApiError('MAX: неожиданный ответ API.')
    return value


def read_status():
    cfg = json.loads(SETTINGS.read_text(encoding='utf-8-sig'))
    children = cfg.get('children')
    if not isinstance(children, dict) or not children:
        raise ValueError('В семейных настройках не указан список детей.')

    # View-only: never create/migrate/write to the active database.
    if not DB.exists():
        raise FileNotFoundError('База учёта времени не найдена.')
    db_uri = DB.resolve().as_uri() + '?mode=ro'
    with sqlite3.connect(db_uri, uri=True, timeout=8) as conn:
        rows = conn.execute('SELECT username, seconds FROM usage WHERE day=?',
                            (date.today().isoformat(),)).fetchall()
        used_map = {str(user).casefold(): max(0, int(seconds)) for user, seconds in rows}
        try:
            extras = conn.execute('SELECT username, bonus_minutes FROM allowances WHERE day=?',
                                  (date.today().isoformat(),)).fetchall()
            bonus_map = {str(user).casefold(): max(0, int(n)) for user, n in extras}
        except sqlite3.OperationalError as e:
            raise ValueError('Не удалось прочесть таблицу дополнительных минут: '+str(e))

    state = json.loads(ENFORCE.read_text(encoding='utf-8-sig')) if ENFORCE.exists() else {}
    allowed = {str(x).casefold() for x in state.get('enabled_for', [])}
    pause_until = state.get('pause_until', {})
    import time
    now = time.time()

    lines = ['ChildControl · '+date.today().strftime('%d.%m.%Y')]
    for user, base in children.items():
        if not isinstance(user, str) or type(base) is not int or not (1 <= base <= 1440):
            raise ValueError('Ошибка имени/лимита в настройках.')
        key = user.casefold()
        used = used_map.get(key, 0)
        limit = min(1440, base + bonus_map.get(key, 0))
        remain = max(0, limit * 60 - used)
        enabled = key in allowed
        pause = int(pause_until.get(key, 0)) > now
        label = 'пауза' if pause and enabled else 'вкл' if enabled else 'выкл'
        lines.append('{}: использовано {} мин, осталось {} мин, лимит {} мин, контроль {}'.format(
            user, used // 60, (remain + 59) // 60, limit, label))
    lines.append('ПК: '+os.environ.get('COMPUTERNAME', 'неизвестно'))
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser(description='ChildControl 4.7: тест связи семейного ПК с MAX')
    parser.add_argument('action', choices=('preview', 'send'))
    args = parser.parse_args()
    admin_required()
    status = read_status()
    print(status)
    if args.action == 'preview':
        print('\nТолько чтение. Сообщение в MAX не отправлялось.')
        return 0
    print('\nСообщение будет отправлено только подтверждённому родительскому MAX user_id.')
    if input('Отправить отчёт? [да/нет]: ').strip().lower() not in ('да', 'д', 'yes', 'y'):
        print('Отменено.')
        return 0
    token = getpass.getpass('Токен MAX (не отображается): ').strip()
    if not token or token.lower().startswith('bearer ') or token.startswith(('"', "'")):
        raise ValueError('Введи токен без кавычек и приставки Bearer.')
    bot = api_request(token, 'GET', '/me')
    if str(bot.get('user_id')) != str(EXPECTED_BOT_ID):
        raise ValueError('Это токен другого бота MAX. Ничего не отправлено.')
    api_request(token, 'POST', '/messages?user_id='+str(PARENT_USER_ID), {'text': status})
    print('MAX принял отчёт. Токен не сохранён на диске.')
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ApiError, ValueError, OSError, sqlite3.Error, PermissionError) as exc:
        print('ОШИБКА: '+str(exc), file=sys.stderr)
        sys.exit(1)
