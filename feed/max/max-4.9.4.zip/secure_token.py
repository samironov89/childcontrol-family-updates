# -*- coding: utf-8 -*-
"""Store MAX token encrypted by Windows DPAPI (LocalMachine), with NTFS ACL protection.

This is for a dedicated Windows family PC. Even with machine-scope DPAPI,
secrecy depends on NTFS ACL: SYSTEM and Administrators only may read the blob.
"""
from __future__ import annotations

import ctypes
from ctypes import wintypes as wt
import os
from pathlib import Path

ROOT = Path(os.environ.get('ProgramData', r'C:\ProgramData')) / 'ChildControlMAX'
TOKEN_FILE = ROOT / 'max-token.dpapi'
CRYPTPROTECT_LOCAL_MACHINE = 0x00000004


class DATA_BLOB(ctypes.Structure):
    _fields_ = [('cbData', wt.DWORD), ('pbData', ctypes.POINTER(wt.BYTE))]


def _win_libs():
    if os.name != 'nt':
        raise OSError('DPAPI доступен только в Windows')
    crypt32 = ctypes.WinDLL('crypt32', use_last_error=True)
    kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
    crypt32.CryptProtectData.argtypes = [
        ctypes.POINTER(DATA_BLOB), wt.LPCWSTR, ctypes.POINTER(DATA_BLOB),
        ctypes.c_void_p, ctypes.c_void_p, wt.DWORD, ctypes.POINTER(DATA_BLOB)
    ]
    crypt32.CryptProtectData.restype = wt.BOOL
    crypt32.CryptUnprotectData.argtypes = [
        ctypes.POINTER(DATA_BLOB), ctypes.POINTER(ctypes.c_wchar_p),
        ctypes.POINTER(DATA_BLOB), ctypes.c_void_p, ctypes.c_void_p,
        wt.DWORD, ctypes.POINTER(DATA_BLOB)
    ]
    crypt32.CryptUnprotectData.restype = wt.BOOL
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p
    return crypt32, kernel32


def _to_blob(raw: bytes):
    # Buffer must live until Windows API has returned.
    buf = ctypes.create_string_buffer(raw)
    return DATA_BLOB(len(raw), ctypes.cast(buf, ctypes.POINTER(wt.BYTE))), buf


def protect(token: str) -> bytes:
    crypt32, kernel32 = _win_libs()
    source, sourcebuf = _to_blob(token.encode('utf-8'))
    result = DATA_BLOB()
    if not crypt32.CryptProtectData(ctypes.byref(source), 'ChildControl MAX', None,
                                    None, None, CRYPTPROTECT_LOCAL_MACHINE,
                                    ctypes.byref(result)):
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        return ctypes.string_at(result.pbData, result.cbData)
    finally:
        kernel32.LocalFree(ctypes.cast(result.pbData, ctypes.c_void_p))


def unprotect(ciphertext: bytes) -> str:
    crypt32, kernel32 = _win_libs()
    source, sourcebuf = _to_blob(ciphertext)
    result = DATA_BLOB()
    if not crypt32.CryptUnprotectData(ctypes.byref(source), None, None,
                                      None, None, 0, ctypes.byref(result)):
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        return ctypes.string_at(result.pbData, result.cbData).decode('utf-8')
    finally:
        kernel32.LocalFree(ctypes.cast(result.pbData, ctypes.c_void_p))


def save(token: str) -> None:
    if not ROOT.is_dir():
        raise FileNotFoundError('Сначала выполни Install из setup.ps1: ' + str(ROOT))
    raw = protect(token)
    temp = TOKEN_FILE.with_suffix('.tmp')
    with temp.open('wb') as f:
        f.write(raw)
    temp.replace(TOKEN_FILE)


def load() -> str:
    if not TOKEN_FILE.is_file():
        raise FileNotFoundError('Токен MAX ещё не сохранён. Выполни save-token.')
    return unprotect(TOKEN_FILE.read_bytes())
