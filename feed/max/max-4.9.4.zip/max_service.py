# -*- coding: utf-8 -*-
"""ChildControl 4.9: background MAX read-only command worker.

Runs as SYSTEM on boot, independently of signed-in parents. No changes to
ChildControl controller, local limits, child sessions or Windows passwords.
Only accepts /status and /help from configured parent in private chat.
"""
from __future__ import annotations

import argparse
from collections import deque
import getpass
import json
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import sqlite3
import sys
import time

from max_bot import (SingleInstance, AlreadyRunning, authorized_message,
                     check_bot_and_webhook, ensure_token, get_updates,
                     reply_for_command, send_to_parent)
from max_status import ApiError, admin_required, PARENT_USER_ID
from secure_token import ROOT, load, save

LOG_FILE = ROOT / 'max_bot.log'
STATE_FILE = ROOT / 'max_bot_state.json'
# Do not execute commands queued for more than five minutes while offline.
MAX_COMMAND_AGE_MS = 5 * 60 * 1000
ADMINS_FILE = ROOT / 'admin_ids.json'


def read_admins():
    ids = {str(PARENT_USER_ID)}
    try:
        payload = json.loads(ADMINS_FILE.read_text(encoding='utf-8'))
    except FileNotFoundError:
        return ids
    if not isinstance(payload, dict) or not isinstance(payload.get('admins'), list):
        raise ValueError('Invalid admin_ids.json format')
    for candidate in payload['admins']:
        if isinstance(candidate, bool) or not str(candidate).isdigit():
            raise ValueError('Invalid admin ID in settings')
        ids.add(str(candidate))
    return ids


def add_admin(user_id):
    admin_required()
    if not str(user_id).isdigit() or not 5 <= len(str(user_id)) <= 20:
        raise ValueError('Invalid MAX user ID')
    ids = read_admins()
    ids.add(str(user_id))
    ROOT.mkdir(parents=True, exist_ok=True)
    tmp = ROOT / 'admin_ids.tmp'
    tmp.write_text(json.dumps({'admins': sorted(ids)}, ensure_ascii=False), encoding='utf-8')
    tmp.replace(ADMINS_FILE)
    return len(ids)



def configure_log():
    ROOT.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger('ChildControlMAX')
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    h = RotatingFileHandler(LOG_FILE, maxBytes=1_000_000, backupCount=3,
                            encoding='utf-8')
    h.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
    logger.addHandler(h)
    return logger


def load_marker():
    try:
        data = json.loads(STATE_FILE.read_text(encoding='utf-8'))
    except (OSError, ValueError, TypeError):
        return None
    value = data.get('marker') if isinstance(data, dict) else None
    if value is None:
        return None
    # Protect request parameters from corrupted local state.
    if not str(value).isdigit():
        return None
    return str(value)


def save_marker(marker):
    if marker is None:
        return
    tmp = STATE_FILE.with_suffix('.tmp')
    tmp.write_text(json.dumps({'marker': str(marker)}), encoding='utf-8')
    tmp.replace(STATE_FILE)


def fresh_event(event, now_ms):
    # MAX currently returns timestamps in epoch milliseconds; allow seconds too.
    value = event.get('timestamp')
    if not isinstance(value, (float, int)) or isinstance(value, bool):
        return False
    timestamp = int(value)
    if timestamp < 10_000_000_000:
        timestamp *= 1000
    return 0 <= now_ms - timestamp <= MAX_COMMAND_AGE_MS


def service_loop(token, *, request=None, logger=None, shutdown=None):
    # Injected request exists for offline tests; production uses prior tested 4.8 API.
    if request is None:
        from max_status import api_request
        request = api_request
    if logger is None:
        logger = configure_log()
    logger.info('MAX 4.9 booted; service running as %s', os.environ.get('USERNAME', '?'))
    # Windows can start the task before Wi-Fi/Ethernet becomes available.
    # Keep retrying until network returns; do not exhaust 3 task restarts.
    startup_backoff = 5
    while True:
        try:
            check_bot_and_webhook(token, request)
            marker = load_marker()
            if marker is None:
                # On first installation, do not replay old /help or /status commands.
                _old, marker = get_updates(token, None, request, timeout=0)
                save_marker(marker)
                logger.info('MAX initial cursor set')
            else:
                logger.info('MAX cursor restored')
            break
        except ApiError as exc:
            if 'HTTP 401' in str(exc):
                logger.error('MAX rejected bot token. Save a new token as administrator.')
                raise
            logger.warning('Network unavailable at startup: %s; retry %ss', exc, startup_backoff)
            time.sleep(startup_backoff)
            startup_backoff = min(startup_backoff * 2, 60)
    seen = set()
    seen_order = deque(maxlen=256)
    retry_seconds = 5
    while shutdown is None or not shutdown():
        try:
            updates, next_marker = get_updates(token, marker, request, timeout=20)
            for item in updates:
                if not isinstance(item, dict) or not fresh_event(item, int(time.time() * 1000)):
                    continue
                command = authorized_message(item, read_admins())
                if command is None:
                    continue
                msg = item.get('message') or {}
                body = msg.get('body') or {}
                mid = str(body.get('mid', ''))
                if mid and mid in seen:
                    continue
                sender_id = str((msg.get('sender') or {}).get('user_id', ''))
                if command.lower() == '/myid':
                    answer = 'Твой MAX user_id: ' + sender_id + '\nПередай этот номер Сергею для добавления в администраторы.'
                else:
                    answer = reply_for_command(command)
                if answer is None:
                    continue
                send_to_parent(token, answer, request, user_id=sender_id)
                logger.info('Handled command %s', command.strip().lower() if command.strip().lower() in ('/help','/start','/status') else '<unknown>')
                if mid:
                    if len(seen_order) == seen_order.maxlen:
                        seen.discard(seen_order[0])
                    seen_order.append(mid)
                    seen.add(mid)
                time.sleep(0.6)
            if next_marker is not None:
                marker = next_marker
                save_marker(marker)
            retry_seconds = 5
            time.sleep(0.5)
        except ApiError as exc:
            logger.warning('MAX API: %s; retry in %s sec', exc, retry_seconds)
            if 'HTTP 401' in str(exc):
                logger.error('Authorization rejected; reinstall bot token with save-token')
                raise
            time.sleep(retry_seconds)
            retry_seconds = min(retry_seconds * 2, 60)
        except (OSError, ValueError, sqlite3.Error) as exc:
            logger.warning('Worker failure %s; retry in %s sec', type(exc).__name__, retry_seconds)
            time.sleep(retry_seconds)
            retry_seconds = min(retry_seconds * 2, 60)


def main(args=None):
    parser = argparse.ArgumentParser(description='ChildControl 4.9 read-only MAX listener')
    parser.add_argument('action', choices=['run', 'save-token', 'check-token', 'self-test', 'admin-add', 'admin-list'])
    parser.add_argument('--user-id', default=None)
    opt = parser.parse_args(args)
    if opt.action == 'self-test':
        assert not fresh_event({'timestamp': 0}, int(time.time()*1000))
        assert fresh_event({'timestamp': int(time.time()*1000)}, int(time.time()*1000))
        assert reply_for_command('/status', read=lambda: 'OK') == 'OK'
        assert reply_for_command('/help').startswith('ChildControl')
        print('SELF-TEST OK: локальные проверки пройдены, лимиты не изменялись.')
        return 0
    if opt.action == 'admin-add':
        admin_required()
        if not opt.user_id:
            raise ValueError('Specify --user-id')
        count = add_admin(opt.user_id)
        print('MAX admin added. Total admins: {}'.format(count))
        return 0
    if opt.action == 'admin-list':
        admin_required()
        print('Allowed MAX user IDs: ' + ', '.join(sorted(read_admins())))
        return 0
    if opt.action == 'save-token':
        admin_required()
        token = ensure_token(getpass.getpass('Токен MAX (ввод скрыт): '))
        bot = check_bot_and_webhook(token)
        save(token)
        print('Токен бота {} проверен и зашифрован в хранилище компьютера.'.format(bot.get('user_id')))
        return 0
    if opt.action == 'check-token':
        admin_required()
        bot = check_bot_and_webhook(load())
        print('MAX доступен, токен бота {} проверен.'.format(bot.get('user_id')))
        return 0
    # Task Scheduler runs this command as SYSTEM (no parent login required).
    # This checks only logged-in identity string, not authorization: access to
    # restricted files is controlled by SYSTEM/Administrators NTFS permissions.
    with SingleInstance():
        service_loop(load())
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (AlreadyRunning, ApiError, OSError, ValueError, PermissionError) as exc:
        # Never print credentials or raw MAX message bodies.
        try:
            configure_log().error('Exit: %s', exc)
        except OSError:
            pass
        print('ОШИБКА: {}'.format(type(exc).__name__), file=sys.stderr)
        sys.exit(1)
