# -*- coding: utf-8 -*-
"""ChildControl 4.8: MAX read-only commands, foreground development test.

No modification to ChildControl service, Windows sessions, user accounts,
limits, database, token storage, or system tasks. Only /status and /help.
"""
from __future__ import annotations

import argparse
from collections import deque
import ctypes
import getpass
import os
import sys
import time
from urllib.parse import urlencode

from max_status import (
    ApiError, EXPECTED_BOT_ID, PARENT_USER_ID,
    admin_required, api_request, read_status,
)

POLL_SECONDS = 20
LOCK_NAME = r'Global\ChildControlMAXBot48ReadOnly'


class AlreadyRunning(RuntimeError):
    pass


class SingleInstance:
    """Prevent two copies of this test listener on the same Windows machine."""

    def __init__(self):
        self.handle = None

    def __enter__(self):
        if os.name != 'nt':
            return self
        import ctypes.wintypes as wt
        k32 = ctypes.WinDLL('kernel32', use_last_error=True)
        create = k32.CreateMutexW
        create.argtypes = [ctypes.c_void_p, wt.BOOL, wt.LPCWSTR]
        create.restype = wt.HANDLE
        self.handle = create(None, False, LOCK_NAME)
        error = ctypes.get_last_error()
        if not self.handle:
            raise OSError('Не удалось создать защиту от повторного запуска')
        if error == 183:  # ERROR_ALREADY_EXISTS
            self.__exit__(None, None, None)
            raise AlreadyRunning('Обработчик MAX уже запущен в другом окне.')
        return self

    def __exit__(self, *_):
        if self.handle:
            close = ctypes.WinDLL('kernel32', use_last_error=True).CloseHandle
            close.argtypes = [ctypes.wintypes.HANDLE]
            close.restype = ctypes.wintypes.BOOL
            close(self.handle)
            self.handle = None


def ensure_token(raw):
    token = raw.strip()
    if not token or token.lower().startswith('bearer ') or token.startswith(('"', "'")):
        raise ValueError('Нужен токен MAX без кавычек и приставки Bearer.')
    return token


def check_bot_and_webhook(token, request=api_request):
    bot = request(token, 'GET', '/me')
    if str(bot.get('user_id')) != str(EXPECTED_BOT_ID):
        raise ValueError('Токен принадлежит другому боту MAX; запуск отменён.')
    subs = request(token, 'GET', '/subscriptions')
    if not isinstance(subs.get('subscriptions'), list):
        raise ValueError('Не удалось подтвердить отсутствие Webhook-подписок.')
    if subs['subscriptions']:
        raise ValueError('Для бота включён Webhook. Long Polling одновременно не работает.')
    return bot


def get_updates(token, marker, request=api_request, *, timeout=POLL_SECONDS):
    params = {'timeout': timeout, 'limit': 100}
    if marker is not None:
        params['marker'] = marker
    result = request(token, 'GET', '/updates?' + urlencode(params))
    updates = result.get('updates')
    if not isinstance(updates, list):
        raise ApiError('MAX вернул ответ без списка updates.')
    next_marker = result.get('marker')
    if next_marker is not None:
        if isinstance(next_marker, bool) or not str(next_marker).isdigit():
            raise ApiError('MAX вернул неизвестный формат marker.')
        next_marker = str(next_marker)
    return updates, next_marker


def authorized_message(update, allowed_ids=None):
    """Return the command text only for the allowed parent's private dialog."""
    if not isinstance(update, dict) or update.get('update_type') != 'message_created':
        return None
    message = update.get('message')
    if not isinstance(message, dict):
        return None
    sender = message.get('sender')
    recipient = message.get('recipient')
    body = message.get('body')
    if not all(isinstance(x, dict) for x in (sender, recipient, body)):
        return None
    if sender.get('is_bot') is True:
        return None
    sender_id = str(sender.get('user_id', ''))
    if not sender_id.isdigit():
        return None
    if recipient.get('chat_type') != 'dialog':
        return None
    # The receiver of an incoming private message should be this bot.
    received_by = recipient.get('user_id')
    if received_by is not None and str(received_by) != str(EXPECTED_BOT_ID):
        return None
    text = body.get('text')
    if not isinstance(text, str):
        return None
    command = text.strip()
    # Anyone can ask for their own public MAX account identifier, but no other data.
    if command.lower() == '/myid':
        return command
    permitted = set(map(str, allowed_ids)) if allowed_ids is not None else {str(PARENT_USER_ID)}
    if sender_id not in permitted:
        return None
    return command


def reply_for_command(command, read=read_status):
    """Static allowlist of read-only commands. Never invoke local commands."""
    normalized = command.strip().lower()
    if normalized == '/status':
        return read()
    if normalized in ('/help', '/start'):
        return (
            'ChildControl 4.9 — фоновые команды MAX\n'
            '/status — время Дмитрия и Юлии\n'
            '/help — список команд\n\n'
            'Только чтение: изменить лимит или завершить сеанс через этого бота нельзя.'
        )
    if normalized.startswith('/'):
        return 'Неизвестная команда. Доступны /status и /help.'
    return None


def send_to_parent(token, text, request=api_request, *, user_id=None):
    recipient = PARENT_USER_ID if user_id is None else user_id
    if not str(recipient).isdigit():
        raise ValueError('Invalid destination MAX ID')
    return request(token, 'POST', '/messages?user_id=' + str(recipient), {'text': text})


def run_loop(token, *, minutes=15, request=api_request, now=time.time,
             sleep=time.sleep, output=print):
    check_bot_and_webhook(token, request)
    start_ms = round(now() * 1000)
    # Read and skip the last preexisting update before advertising readiness.
    # If no cursor is returned, timestamps still filter messages predating this run.
    previous, marker = get_updates(token, None, request, timeout=0)
    del previous
    deadline = now() + minutes * 60
    seen = set()
    seen_order = deque(maxlen=256)
    output('MAX подключён. Команды разрешены только в личном диалоге родителя.')
    output('СЕЙЧАС отправь боту /help, затем /status. Остановить: Ctrl+C.')
    # Readiness notification is sent after the cursor is initialized.
    send_to_parent(token, 'ChildControl 4.8: тест запущен. Отправь /help или /status.', request)
    sleep(0.6)
    while now() < deadline:
        try:
            updates, next_marker = get_updates(token, marker, request, timeout=POLL_SECONDS)
            for update in updates:
                if not isinstance(update, dict):
                    continue
                raw_timestamp = update.get('timestamp')
                # Reject old queued commands if the server returned latest events again.
                if isinstance(raw_timestamp, (float, int)) and raw_timestamp < start_ms - 3000:
                    continue
                command = authorized_message(update)
                if command is None:
                    continue
                message = update.get('message', {})
                body = message.get('body', {})
                mid = str(body.get('mid', ''))
                if mid and mid in seen:
                    continue
                reply = reply_for_command(command)
                if reply is None:
                    continue
                send_to_parent(token, reply, request)
                output('Обработана команда: ' + command[:40])
                if mid:
                    if len(seen_order) == seen_order.maxlen:
                        seen.discard(seen_order[0])
                    seen_order.append(mid)
                    seen.add(mid)
                sleep(0.6)  # MAX: <= 2 messages per second per dialog.
            if next_marker is not None:
                marker = next_marker
            # Bound request rate even if the server repeats already seen events.
            sleep(0.5)
        except ApiError as exc:
            if 'HTTP 401' in str(exc):
                raise
            output('Временная ошибка связи: {}. Повтор через 5 секунд.'.format(exc))
            sleep(5)
    output('Тест завершён по таймеру. Контроллер ChildControl не затронут.')


def main(argv=None):
    p = argparse.ArgumentParser(description='ChildControl 4.8: тест команд MAX /help и /status')
    p.add_argument('action', choices=['listen', 'self-test'])
    p.add_argument('--minutes', type=int, default=15, help='Продолжительность теста 1-60 мин (по умолчанию 15)')
    args = p.parse_args(argv)
    if args.action == 'self-test':
        assert reply_for_command('/help').startswith('ChildControl')
        assert reply_for_command('/status', read=lambda: 'OK') == 'OK'
        assert reply_for_command('other') is None
        print('SELF-TEST OK. Никаких сетевых обращений или изменений Windows.')
        return 0
    if not 1 <= args.minutes <= 60:
        raise ValueError('Укажи --minutes от 1 до 60.')
    admin_required()
    with SingleInstance():
        token = ensure_token(getpass.getpass('Токен MAX (не отображается): '))
        try:
            run_loop(token, minutes=args.minutes)
        except KeyboardInterrupt:
            print('\nОстановлено вручную. Учет времени Windows продолжает работать.')
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ApiError, ValueError, AlreadyRunning, PermissionError, OSError) as exc:
        print('ОШИБКА: {}'.format(exc), file=sys.stderr)
        sys.exit(1)
