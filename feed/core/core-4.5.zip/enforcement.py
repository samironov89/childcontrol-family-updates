"""ChildControl 4.5 local parent-managed enforcement (NO network).

The file is OFF when absent or invalid; the Windows SYSTEM task is the
only process that performs any sign-out. A console administrator can opt in
per child and can disable it. Pauses have an absolute expiry timestamp.
"""
from __future__ import annotations

from datetime import datetime
import json
import os
from pathlib import Path
import tempfile
import time

ROOT = Path(os.environ.get('ProgramData', r'C:\ProgramData')) / 'ChildControl'
STATE_FILE = ROOT / 'enforcement.json'
VERSION = 1
MAX_PAUSE_MINUTES = 240


def off_state():
    return {'version': VERSION, 'enabled_for': [], 'pause_until': {}}


def _normalize(state, children):
    """Strict validation. Never accept unknown users or unknown fields."""
    if not isinstance(state, dict) or set(state) != {'version', 'enabled_for', 'pause_until'}:
        raise ValueError('Неверный формат enforcement.json')
    if type(state['version']) is not int or state['version'] != VERSION:
        raise ValueError('Неизвестная версия enforcement.json')
    enabled = state['enabled_for']
    pauses = state['pause_until']
    if not isinstance(enabled, list) or not isinstance(pauses, dict):
        raise ValueError('Неверный тип полей enforcement.json')
    if any(not isinstance(x, str) or x not in children for x in enabled):
        raise ValueError('Неверное имя в enabled_for')
    if len(set(enabled)) != len(enabled):
        raise ValueError('Повтор учётной записи')
    for user, expires in pauses.items():
        if user not in children or type(expires) is not int or expires < 0:
            raise ValueError('Неверное значение pause_until')
    return {'version': VERSION, 'enabled_for': list(enabled), 'pause_until': dict(pauses)}


def read_state(children, path=STATE_FILE):
    """Fail open: if missing, unreadable, corrupted, return disabled state."""
    try:
        path = Path(path)
        if not path.is_file():
            return off_state()
        return _normalize(json.loads(path.read_text(encoding='utf-8-sig')), children)
    except (OSError, ValueError, UnicodeError, TypeError, KeyError):
        return off_state()


def read_state_strict(children, path=STATE_FILE):
    """For ADMIN mutations: refuse overwrite if existing state is malformed."""
    path = Path(path)
    if not path.is_file():
        return off_state()
    return _normalize(json.loads(path.read_text(encoding='utf-8-sig')), children)


def write_state(state, children, path=STATE_FILE):
    """Atomically persist. Called only after require_admin by controller CLI."""
    state = _normalize(state, children)
    path = Path(path)
    if not path.parent.is_dir():
        raise RuntimeError('Защищённая папка отсутствует: '+str(path.parent))
    payload = (json.dumps(state, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode('utf-8')
    fd, tmp = tempfile.mkstemp(prefix='.enforce-', suffix='.tmp', dir=str(path.parent))
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(payload)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def permitted(state, key, now=None):
    if not state or key not in state.get('enabled_for', []):
        return False
    if now is None:
        now = time.time()
    return int(state.get('pause_until', {}).get(key, 0)) <= now


def active_pause_until(state, key, now=None):
    if now is None:
        now = time.time()
    until = int(state.get('pause_until', {}).get(key, 0))
    return until if until > now else 0


def pretty_pause(until):
    if not until:
        return 'нет'
    return datetime.fromtimestamp(until).strftime('%Y-%m-%d %H:%M:%S')
