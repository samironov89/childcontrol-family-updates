"""Time-limited, parent-controlled opt-in for TEST sign-out on a local PC.

The guard is OFF if its file is missing, disabled, invalid or expired.
No account disabling, password changes, login-provider modifications, or network.
"""
from __future__ import annotations
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import tempfile
import time

ROOT = Path(os.environ.get('ProgramData', r'C:\ProgramData')) / 'ChildControl'
GUARD_FILE = ROOT / 'guard.json'
MAX_ARM_MINUTES = 20


def off_state():
    return {'version': 1, 'enabled': False, 'target_user': '', 'expires_at': 0}


def arm_state(username, children, minutes=10, now=None):
    if not isinstance(username, str) or username.casefold() not in children:
        raise ValueError('Разрешены только учётные записи детей из настроек')
    if type(minutes) is not int or not (1 <= minutes <= MAX_ARM_MINUTES):
        raise ValueError('Период разрешения: от 1 до 20 минут')
    if now is None:
        now = time.time()
    return {'version': 1, 'enabled': True,
            'target_user': children[username.casefold()][0],
            'expires_at': int(now) + 60 * minutes}


def load_guard(path=GUARD_FILE, now=None):
    """Read and validate guard. Raise on malformed file (caller must fail safe)."""
    path = Path(path)
    if not path.is_file():
        return off_state()
    payload = json.loads(path.read_text(encoding='utf-8-sig'))
    if (not isinstance(payload, dict) or type(payload.get('version')) is not int or
        payload['version'] != 1 or type(payload.get('enabled')) is not bool or
        not isinstance(payload.get('target_user'), str) or
        type(payload.get('expires_at')) is not int):
        raise ValueError('guard.json повреждён или имеет неизвестную структуру')
    if now is None:
        now = time.time()
    if not payload['enabled'] or payload['expires_at'] <= now:
        return off_state()
    if not payload['target_user'].strip():
        raise ValueError('guard.json: отсутствует пользователь')
    return payload


def active_for(guard, username, children, now=None):
    if not username or not guard.get('enabled'):
        return False
    key = username.casefold()
    return key in children and guard.get('target_user', '').casefold() == key and (
        now is None or guard.get('expires_at', 0) > now)


def write_guard(state, path=GUARD_FILE):
    """Atomic write; caller must have Administrator rights and secure parent dir."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = (json.dumps(state, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    fd, temp_name = tempfile.mkstemp(prefix='.guard-', suffix='.tmp', dir=str(path.parent))
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(payload)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp_name, path)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)


def format_expiration(state):
    if not state.get('enabled'):
        return 'ОТКЛЮЧЕНО'
    until = datetime.fromtimestamp(state['expires_at'], tz=timezone.utc).astimezone()
    return 'ВКЛ для {} до {}'.format(state['target_user'], until.strftime('%Y-%m-%d %H:%M:%S %Z'))
