"""ChildControl Family 4.5: local time quotas, notifications, parental controls.

SYSTEM task counts physical unlocked child sessions. All real sign-outs are
OFF until a Windows administrator deliberately enables them per child.
No account disable, password changes, screenshots or network access.
"""
from __future__ import annotations

import argparse
import ctypes
from ctypes import wintypes
from datetime import date
import json
import logging
import os
import subprocess
from pathlib import Path
import sqlite3
import sys
import time

from policy import decide, explain, DEFAULT_GRACE_SECONDS
from guard import (GUARD_FILE, arm_state, off_state, load_guard,
                   active_for, write_guard, format_expiration)
from enforcement import (STATE_FILE, off_state as permanent_off_state,
                         read_state, read_state_strict, write_state,
                         permitted, active_pause_until, pretty_pause,
                         MAX_PAUSE_MINUTES)

ROOT = Path(os.environ.get('ProgramData', r'C:\ProgramData')) / 'ChildControl'
CFG = ROOT / 'family_settings.json'
DB = ROOT / 'usage.sqlite3'
LOG = ROOT / 'controller.log'


def load_settings(path=CFG):
    path = Path(path)
    if path == CFG and not path.is_file():
        path = Path(__file__).resolve().parent / 'family_settings.json'
    settings = json.loads(path.read_text(encoding='utf-8-sig'))
    children = settings.get('children')
    parents = settings.get('parents')
    if not isinstance(children, dict) or not children:
        raise ValueError('children должен быть объектом {"имя": число_минут}')
    if not isinstance(parents, list) or any(not isinstance(n, str) for n in parents):
        raise ValueError('parents должен быть списком имён')
    normalized = {}
    for user, limit in children.items():
        if not isinstance(user, str) or not user.strip() or type(limit) is not int or not 1 <= limit <= 1440:
            raise ValueError('Неверное имя или лимит: '+str(user))
        key = user.strip().casefold()
        if key in normalized or key in {p.casefold() for p in parents}:
            raise ValueError('Повтор имени или пересечение с родителями: '+str(user))
        normalized[key] = (user, limit)
    every = settings.get('poll_seconds', 5)
    if type(every) is not int or not 2 <= every <= 20:
        raise ValueError('poll_seconds должен быть 2–20')
    return normalized, every


class WTSINFOEX_LEVEL1_W(ctypes.Structure):
    # C WCHAR is 2 bytes on Windows; ctypes.c_wchar is Windows-compatible there.
    _fields_ = [
        ('SessionId', wintypes.DWORD),
        ('SessionState', ctypes.c_int),
        ('SessionFlags', ctypes.c_int),
        ('WinStationName', ctypes.c_wchar * 33),
        ('UserName', ctypes.c_wchar * 21),
        ('DomainName', ctypes.c_wchar * 18),
        ('LogonTime', ctypes.c_longlong),
        ('ConnectTime', ctypes.c_longlong),
        ('DisconnectTime', ctypes.c_longlong),
        ('LastInputTime', ctypes.c_longlong),
        ('CurrentTime', ctypes.c_longlong),
        ('IncomingBytes', wintypes.DWORD),
        ('OutgoingBytes', wintypes.DWORD),
        ('IncomingFrames', wintypes.DWORD),
        ('OutgoingFrames', wintypes.DWORD),
        ('IncomingCompressedBytes', wintypes.DWORD),
        ('OutgoingCompressedBytes', wintypes.DWORD),
    ]


class WTSINFOEXW(ctypes.Structure):
    _fields_ = [('Level', wintypes.DWORD), ('Data', WTSINFOEX_LEVEL1_W)]


def _query_wts(session_id, info_class):
    wts = ctypes.WinDLL('Wtsapi32', use_last_error=True)
    fn = wts.WTSQuerySessionInformationW
    fn.argtypes = [wintypes.HANDLE, wintypes.DWORD, ctypes.c_int,
                   ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(wintypes.DWORD)]
    fn.restype = wintypes.BOOL
    free_fn = wts.WTSFreeMemory
    free_fn.argtypes = [ctypes.c_void_p]
    free_fn.restype = None
    mem = ctypes.c_void_p()
    size = wintypes.DWORD()
    if not fn(0, session_id, info_class, ctypes.byref(mem), ctypes.byref(size)):
        return None
    try:
        return ctypes.string_at(mem, size.value) if mem and size.value else None
    finally:
        if mem:
            free_fn(mem)


def active_console():
    """Return (username, unlocked, reason), unlocked=None on uncertain state.

    Windows WTS session flags: 0=locked, 1=unlocked, -1=unknown.
    Only the physical active console, not remote sessions, is counted.
    """
    if os.name != 'nt':
        raise RuntimeError('Этот тест работает только в Windows')
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.WTSGetActiveConsoleSessionId.restype = wintypes.DWORD
    sid = kernel.WTSGetActiveConsoleSessionId()
    if sid == 0xFFFFFFFF:
        return None, None, 'активная сессия отсутствует'
    # WTSUserName = 5, WTSSessionInfoEx = 25
    name_data = _query_wts(sid, 5)
    if not name_data:
        return None, None, 'имя пользователя недоступно'
    username = name_data.decode('utf-16-le').split('\x00', 1)[0].strip()
    if not username:
        return None, None, 'пользователь не вошёл'
    data = _query_wts(sid, 25)
    if not data or len(data) < ctypes.sizeof(WTSINFOEXW):
        return username, None, 'WTSSessionInfoEx недоступен'
    info = WTSINFOEXW.from_buffer_copy(data)
    if info.Level != 1 or info.Data.SessionId != sid:
        return username, None, 'некорректные сведения о сессии'
    # WTSActive == 0; 0 locked; 1 unlocked (Windows 10/11).
    if info.Data.SessionState != 0:
        return username, False, 'сессия не активна'
    if info.Data.SessionFlags == 1:
        return username, True, 'экран разблокирован'
    if info.Data.SessionFlags == 0:
        return username, False, 'экран заблокирован'
    return username, None, 'неизвестное состояние блокировки'




def is_system_account():
    """Use Windows' stable SID rather than localized USERNAME (SYSTEM/СИСТЕМА)."""
    if os.name != 'nt':
        return False
    whoami = os.path.join(os.environ.get('SystemRoot', r'C:\Windows'),
                         'System32', 'whoami.exe')
    result = subprocess.check_output([whoami, '/user'], stderr=subprocess.STDOUT)
    return b'S-1-5-18' in result


def send_notification(target_user, headline, message, timeout=40):
    """Show a visible dialog in the unlocked physical console user session.

    WTSSendMessageW uses the number of BYTES of UTF-16LE text, not character
    counts. No user-agent, network or admin message window is needed.
    """
    if os.name != 'nt':
        raise RuntimeError('Уведомление можно проверить только в Windows')
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.WTSGetActiveConsoleSessionId.restype = wintypes.DWORD
    sid = kernel.WTSGetActiveConsoleSessionId()
    if sid == 0xFFFFFFFF:
        raise RuntimeError('Нет активной консольной сессии')
    # Verify the user again just before sending; avoid messaging a different account.
    current_user, unlocked, _ = active_console()
    if not current_user or current_user.casefold() != target_user.casefold() or unlocked is not True:
        raise RuntimeError('Целевая учётная запись не является активной разблокированной сессией')
    name_raw = _query_wts(sid, 5)
    confirmed_name = name_raw.decode('utf-16-le').split('\x00', 1)[0].strip() if name_raw else ''
    if confirmed_name.casefold() != target_user.casefold():
        raise RuntimeError('Консольная сессия изменилась перед отправкой')

    wts = ctypes.WinDLL('Wtsapi32', use_last_error=True)
    fn = wts.WTSSendMessageW
    fn.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPCWSTR,
                   wintypes.DWORD, wintypes.LPCWSTR, wintypes.DWORD,
                   wintypes.DWORD, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD),
                   wintypes.BOOL]
    fn.restype = wintypes.BOOL
    response = wintypes.DWORD(0)
    # MB_OK | MB_ICONINFORMATION = 0x40. bWait=False prevents blocking accounting.
    success = fn(0, sid, headline, len(headline.encode('utf-16-le')),
                 message, len(message.encode('utf-16-le')),
                 0x40, timeout, ctypes.byref(response), False)
    if not success:
        raise ctypes.WinError(ctypes.get_last_error())
    return True


def alert_level(used_seconds, limit_minutes):
    """0=not yet, 1=15min remaining, 2=5min, 3=limit exhausted."""
    remaining = limit_minutes * 60 - used_seconds
    if remaining <= 0:
        return 3
    if remaining <= 5 * 60:
        return 2
    if remaining <= 15 * 60:
        return 1
    return 0


def alert_text(username, level, limit_minutes):
    title = 'ChildControl — время за компьютером'
    if level == 1:
        return title, ('Осталось 15 минут разрешённого времени на сегодня. '
                       'Пожалуйста, сохрани работу заранее.')
    if level == 2:
        return title, ('Осталось 5 минут разрешённого времени на сегодня. '
                       'Пожалуйста, заверши игру и сохрани работу.')
    if level == 3:
        return title, ('Разрешённое время на сегодня закончилось. '
                       'Сохрани работу. Если ограничение включено родителем, '
                       'Windows завершит сеанс после дополнительной минуты.')
    raise ValueError('Неизвестный уровень предупреждения')


def maybe_send_alert(conn, day, username, limit_minutes, used_seconds,
                     notify=send_notification, attempts=None, now=None):
    """One alert per crossed threshold, reliably persisted in protected SQLite.

    On a jump past multiple levels, only the most urgent alert is displayed;
    previous levels are considered superseded. Failures can be retried, at
    most once per 90s for each level within this running process.
    """
    level = alert_level(used_seconds, limit_minutes)
    if not level:
        return False
    old = conn.execute('SELECT level FROM alert_state WHERE day=? AND username=?',
                       (day, username)).fetchone()
    last_level = int(old[0]) if old else 0
    if level <= last_level:
        return False
    if attempts is not None:
        key = (day, username, level)
        timestamp = time.monotonic() if now is None else now
        if timestamp - attempts.get(key, -10**10) < 90:
            return False
        attempts[key] = timestamp
    title, msg = alert_text(username, level, limit_minutes)
    try:
        notify(username, title, msg)
    except Exception as exc:
        logging.warning('warning failed: user=%s level=%s error=%s', username, level, exc)
        return False
    conn.execute('INSERT INTO alert_state (day, username, level) VALUES (?,?,?) '
                 'ON CONFLICT(day,username) DO UPDATE SET level=excluded.level',
                 (day, username, level))
    conn.commit()
    logging.info('alert delivered user=%s day=%s level=%s', username, day, level)
    return True



def connect_db(path=DB):
    conn = sqlite3.connect(str(path), timeout=15)
    conn.execute('CREATE TABLE IF NOT EXISTS usage ('
                 'day TEXT NOT NULL, username TEXT NOT NULL, seconds REAL NOT NULL DEFAULT 0,'
                 'PRIMARY KEY(day,username))')
    conn.execute('CREATE TABLE IF NOT EXISTS alert_state ('
                 'day TEXT NOT NULL, username TEXT NOT NULL, level INTEGER NOT NULL, '
                 'PRIMARY KEY(day,username))')
    conn.execute('CREATE TABLE IF NOT EXISTS allowances ('
                 'day TEXT NOT NULL, username TEXT NOT NULL, bonus_minutes INTEGER NOT NULL DEFAULT 0,'
                 'PRIMARY KEY(day,username))')
    conn.execute('CREATE TABLE IF NOT EXISTS simulated_actions ('
                 'day TEXT NOT NULL, username TEXT NOT NULL, event TEXT NOT NULL, '
                 'created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, '
                 'PRIMARY KEY(day, username, event))')
    conn.commit()
    return conn


def mark_simulated_event(conn, day, username, event):
    """Persist a simulation milestone only once per child per day."""
    cursor = conn.execute('INSERT OR IGNORE INTO simulated_actions '
                          '(day,username,event) VALUES (?,?,?)', (day, username, event))
    conn.commit()
    return cursor.rowcount == 1


def run_policy_simulation(conn, day, username, used_seconds, limit_minutes, is_reentry=False):
    """Only record what an enforcement module WOULD do. Never act on Windows."""
    outcome = decide(used_seconds, limit_minutes)
    if outcome.phase in ('grace', 'would_sign_out'):
        if mark_simulated_event(conn, day, username, 'grace_started'):
            logging.info('DRY_RUN grace_started user=%s day=%s: would allow %ss to save work; no logout',
                         username, day, DEFAULT_GRACE_SECONDS)
    if outcome.phase == 'would_sign_out':
        if mark_simulated_event(conn, day, username, 'would_sign_out'):
            logging.info('DRY_RUN would_sign_out user=%s day=%s: NO WINDOWS ACTION EXECUTED',
                         username, day)
        if is_reentry:
            logging.info('DRY_RUN would_deny_reentry user=%s day=%s: NO WINDOWS ACTION EXECUTED',
                         username, day)
    return outcome


def add_usage(conn, day, username, seconds):
    if seconds <= 0:
        return
    conn.execute('INSERT OR IGNORE INTO usage(day, username, seconds) VALUES (?, ?, 0)', (day, username))
    conn.execute('UPDATE usage SET seconds=seconds+? WHERE day=? AND username=?', (seconds, day, username))
    conn.commit()


def usage_today(conn, day, username):
    record = conn.execute('SELECT seconds FROM usage WHERE day=? AND username=?', (day, username)).fetchone()
    return float(record[0]) if record else 0.0


def extra_today(conn, day, username):
    row = conn.execute('SELECT bonus_minutes FROM allowances WHERE day=? AND username=?',
                       (day, username)).fetchone()
    return int(row[0]) if row else 0


def effective_minutes(conn, day, username, base_limit):
    return min(1440, base_limit + extra_today(conn, day, username))


def probe():
    children, _ = load_settings()
    user, unlocked, reason = active_console()
    is_child = bool(user and user.casefold() in children)
    print('ChildControl 4.5 — проверка центрального контроллера')
    print('Учётная запись: '+(user or '(нет)'))
    print('Состояние: '+reason)
    print('Подпадает под учёт: '+('ДА' if is_child else 'НЕТ'))
    print('Предупреждения: 15/5/0 минут; выход по умолчанию ВЫКЛ; включение администратором по каждому ребёнку')
    if unlocked is None and user:
        print('ВНИМАНИЕ: не удалось подтвердить состояние экрана. Время не будет учитываться.')
        return 2
    return 0


def status():
    children, _ = load_settings()
    if not DB.exists():
        print('Статистики центрального контроллера пока нет. Запустите системное задание после проверки.')
        return 0
    today = date.today().isoformat()
    with connect_db() as conn:
        for key, (name, limit) in children.items():
            used = int(usage_today(conn, today, key))
            effective = effective_minutes(conn, today, key, limit)
            outcome = decide(used, effective)
            state = read_state(children)
            pause = active_pause_until(state, key)
            status = 'ВКЛ' if key in state['enabled_for'] else 'ВЫКЛ'
            if pause:
                status += ' (пауза до '+pretty_pause(pause)+')'
            print(f'{today} | {name}: {used//60} мин {used%60} сек / {effective} мин '
                  f'(ограничение: {status}; модель: {outcome.phase})')
    return 0


def require_admin():
    if os.name != 'nt' or not ctypes.windll.shell32.IsUserAnAdmin():
        raise RuntimeError('Операция доступна только из PowerShell администратора')


def cli_guard_status():
    require_admin()
    state = load_guard()
    print('Реальное завершение сеанса: ' + format_expiration(state))
    print('Без изменений паролей и блокировки Windows-входа.')
    return 0


def cli_guard_off():
    require_admin()
    write_guard(off_state())
    print('АВАРИЙНОЕ ОТКЛЮЧЕНИЕ: реальные завершения сеансов запрещены.')
    print('Изменение вступит в силу при следующей проверке контроллера (~5 сек).')
    return 0


def cli_guard_arm(username, minutes):
    require_admin()
    children, _ = load_settings()
    state = arm_state(username, children, minutes)
    print('ВНИМАНИЕ! ТЕСТ РЕАЛЬНОГО ЗАВЕРШЕНИЯ СЕАНСА')
    print('Ребёнок: ' + state['target_user'])
    print('Разрешение завершится автоматически: ' + format_expiration(state))
    print('Если лимит уже превышен на 60 секунд, сеанс завершится после проверки (~5 сек).')
    print('Несохранённые документы при выходе могут быть потеряны.')
    print('Отмена: controller.py guard-off — из PowerShell администратора.')
    answer = input('Для включения введи ровно ENABLE: ').strip()
    if answer != 'ENABLE':
        print('Отменено. Изменений нет.')
        return 0
    write_guard(state)
    print('Разрешён временный тест для ' + state['target_user'])
    return 0


def cli_guard_preview():
    require_admin()
    children, _ = load_settings()
    today = date.today().isoformat()
    state = load_guard()
    print('Реальный выход: ' + format_expiration(state))
    with connect_db() as conn:
        for key, (name, limit) in children.items():
            used = usage_today(conn, today, key)
            outcome = decide(used, limit)
            print('{}: {:.0f}/{:.0f} сек, модель={}, реальное завершение={}'.format(
                name, used, limit * 60, outcome.phase,
                'РАЗРЕШЕНО ПО ВРЕМЕННОМУ ДОПУСКУ' if active_for(state, name, children)
                else 'ЗАПРЕЩЕНО'))
    return 0


def cli_enforce_status():
    require_admin()
    children, _ = load_settings()
    today = date.today().isoformat()
    state = read_state(children)
    with connect_db() as conn:
        for key, (name, limit) in children.items():
            extra = extra_today(conn, today, key)
            used = int(usage_today(conn, today, key))
            pause = active_pause_until(state, key)
            enabled = key in state['enabled_for']
            print('{}: использовано {} сек / {} мин (базовый {} + доп. {}). Ограничение: {}. Пауза: {}'.format(
                name, used, effective_minutes(conn, today, key, limit), limit, extra,
                'ВКЛ' if enabled else 'ВЫКЛ', pretty_pause(pause)))
    return 0


def cli_enforce_on(username):
    require_admin()
    children, _ = load_settings()
    key = str(username or '').casefold()
    if key not in children:
        raise ValueError('Укажи детскую учётную запись через --user')
    print('РЕАЛЬНЫЙ ВЫХОД ИЗ WINDOWS после истечения лимита: '+children[key][0])
    print('Режим постоянный, будет действовать после перезагрузки и при отсутствии интернета.')
    print('Несохранённые данные ребёнка могут быть потеряны при выходе.')
    print('Аварийное отключение: controller.py enforce-off (под администратором).')
    answer = input('Для включения введи ровно ENABLE: ').strip()
    if answer != 'ENABLE':
        print('Отменено.')
        return 0
    state = read_state_strict(children)
    if key not in state['enabled_for']:
        state['enabled_for'].append(key)
    write_state(state, children)
    print('Включено для '+children[key][0]+'. Настройка применяется при следующем опросе (~5 сек).')
    return 0


def cli_enforce_off(username=None):
    require_admin()
    children, _ = load_settings()
    key = (username or 'all').casefold()
    if key != 'all' and key not in children:
        raise ValueError('Укажи детскую учётную запись или all')
    # Also revoke any old temporary 4.4 test authorization.
    write_guard(off_state())
    # Emergency OFF must work even when the optional state file was damaged.
    try:
        state = read_state_strict(children)
    except (OSError, ValueError, KeyError, TypeError, UnicodeError, json.JSONDecodeError):
        state = permanent_off_state()
    if key == 'all':
        state['enabled_for'] = []
    else:
        state['enabled_for'] = [x for x in state['enabled_for'] if x != key]
    write_state(state, children)
    print('ОТКЛЮЧЕНО: ' + ('все детские учётные записи' if key == 'all' else children[key][0]))
    return 0


def cli_pause(username, minutes):
    require_admin()
    children, _ = load_settings()
    key = str(username or '').casefold()
    if key not in children:
        raise ValueError('Укажи детскую учётную запись через --user')
    if type(minutes) is not int or not 1 <= minutes <= MAX_PAUSE_MINUTES:
        raise ValueError('Пауза допустима от 1 до {} минут'.format(MAX_PAUSE_MINUTES))
    state = read_state_strict(children)
    import time as _time
    now = int(_time.time())
    state['pause_until'][key] = max(now, state['pause_until'].get(key, 0)) + minutes * 60
    write_state(state, children)
    print('Пауза для {} до {}. Время продолжает учитываться.'.format(
        children[key][0], pretty_pause(state['pause_until'][key])))
    return 0


def cli_pause_off(username):
    require_admin()
    children, _ = load_settings()
    key = str(username or '').casefold()
    if key not in children:
        raise ValueError('Укажи детскую учётную запись через --user')
    state = read_state_strict(children)
    state['pause_until'].pop(key, None)
    write_state(state, children)
    print('Пауза отменена: '+children[key][0])
    return 0


def cli_add_minutes(username, minutes):
    require_admin()
    children, _ = load_settings()
    key = str(username or '').casefold()
    if key not in children:
        raise ValueError('Укажи детскую учётную запись через --user')
    if type(minutes) is not int or not 1 <= minutes <= 240:
        raise ValueError('Разово можно добавить 1–240 минут')
    day = date.today().isoformat()
    base = children[key][1]
    with connect_db() as conn:
        conn.execute('BEGIN IMMEDIATE')
        existing = extra_today(conn, day, key)
        if base + existing + minutes > 1440:
            raise ValueError('Суммарный дневной лимит не может превышать 24 часа')
        conn.execute('INSERT INTO allowances(day,username,bonus_minutes) VALUES (?,?,?) '
                     'ON CONFLICT(day,username) DO UPDATE SET bonus_minutes=excluded.bonus_minutes',
                     (day, key, existing + minutes))
        # New allowance starts a new warning window for this child today.
        conn.execute('DELETE FROM alert_state WHERE day=? AND username=?', (day, key))
        conn.commit()
        print('{}: добавлено {} мин на {}. Суммарный лимит: {} мин; использованное время сохранено.'.format(
            children[key][0], minutes, day, base + existing + minutes))
    return 0


def logoff_verified_child(target_user):
    """Sign out a child ONLY if physical console/session/user still match.

    Returns False if the child switched away or screen is locked. Must run as
    SYSTEM; caller must first verify child is over quota and parent enabled.
    """
    if not is_system_account():
        raise RuntimeError('Завершение сеанса разрешено только процессу SYSTEM')
    if os.name != 'nt':
        raise RuntimeError('Только Windows')
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.WTSGetActiveConsoleSessionId.restype = wintypes.DWORD
    sid_before = kernel.WTSGetActiveConsoleSessionId()
    if sid_before == 0xFFFFFFFF:
        return False
    user, unlocked, _ = active_console()
    if unlocked is not True or not user or user.casefold() != target_user.casefold():
        return False
    sid_now = kernel.WTSGetActiveConsoleSessionId()
    if sid_now != sid_before:
        return False
    name_data = _query_wts(sid_before, 5)
    confirmed_name = name_data.decode('utf-16-le').split('\x00', 1)[0].strip() if name_data else ''
    if confirmed_name.casefold() != target_user.casefold():
        return False
    wts = ctypes.WinDLL('Wtsapi32', use_last_error=True)
    fn = wts.WTSLogoffSession
    fn.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.BOOL]
    fn.restype = wintypes.BOOL
    if not fn(0, sid_before, False):
        raise ctypes.WinError(ctypes.get_last_error())
    return True


def maybe_enforce(conn, day, username, children, is_reentry=False,
                  last_attempts=None, logoff=logoff_verified_child,
                  guard_loader=None, now=None):
    """Require child whitelist, exhausted effective quota and explicit admin opt-in.

    Invalid or unreadable settings fail open. Pause suppresses all sign-outs.
    """
    if not username or username.casefold() not in children:
        return False
    key = username.casefold()
    used = usage_today(conn, day, key)
    effective = effective_minutes(conn, day, key, children[key][1])
    decision = decide(used, effective)
    if decision.phase != 'would_sign_out':
        return False
    state = read_state(children)
    if active_pause_until(state, key, now=now):
        return False
    always_enabled = permitted(state, key, now=now)
    # Preserve a still-active temporary 4.4 authorization as well.
    try:
        old_guard = (guard_loader or load_guard)()
        temporary = active_for(old_guard, username, children, now=now)
    except (OSError, ValueError, json.JSONDecodeError):
        temporary = False
    if not (always_enabled or temporary):
        return False
    if last_attempts is not None:
        now_tick = time.monotonic()
        if now_tick - last_attempts.get(key, -10**10) < 15:
            return False
        last_attempts[key] = now_tick
    logging.warning('LIVE LOGOFF REQUEST user=%s day=%s reentry=%s used=%.0f limit=%s',
                    username, day, is_reentry, used, effective * 60)
    try:
        result = logoff(username)
    except Exception:
        logging.exception('LIVE LOGOFF FAILED user=%s', username)
        return False
    if result:
        logging.warning('LIVE LOGOFF REQUEST ACCEPTED user=%s day=%s', username, day)
    else:
        logging.warning('LIVE LOGOFF SKIPPED: session changed/locked user=%s', username)
    return bool(result)


def run():
    children, poll = load_settings()
    ROOT.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(filename=str(LOG), encoding='utf-8', level=logging.INFO,
                        format='%(asctime)s %(levelname)s %(message)s')
    logging.info('ChildControl central counter START. users=%s; poll=%ss', ','.join(children), poll)
    # Run installed task as SYSTEM. Do not permit casual use from a child account.
    if not is_system_account():
        raise RuntimeError('Для постоянной работы требуется задача Windows от SYSTEM')
    previous = (None, None, None)  # username, unlocked, local date
    previous_tick = time.monotonic()
    attempts = {}
    logoff_attempts = {}
    with connect_db() as conn:
        while True:
            try:
                user, unlocked, reason = active_console()
                now = time.monotonic()
                current_day = date.today().isoformat()
                prev_user, prev_unlocked, prev_day = previous
                delta = max(0., min(now - previous_tick, poll + 2.))
                key = user.casefold() if user else None
                # Count only time bounded by TWO consecutive unlocked samples.
                if (key in children and key == prev_user and unlocked is True and
                        prev_unlocked is True and prev_day == current_day):
                    add_usage(conn, current_day, key, delta)
                    used = usage_today(conn, current_day, key)
                    effective = effective_minutes(conn, current_day, key, children[key][1])
                    maybe_send_alert(conn, current_day, key, effective, used,
                                     attempts=attempts)
                    run_policy_simulation(conn, current_day, key, used, effective)
                    maybe_enforce(conn, current_day, key, children,
                                  last_attempts=logoff_attempts)
                elif key in children and unlocked is True and (
                        key != prev_user or prev_unlocked is not True):
                    # Evaluate previously exhausted quotas after a new login,
                    # without counting the first uncertain interval.
                    run_policy_simulation(conn, current_day, key,
                                          usage_today(conn, current_day, key),
                                          effective_minutes(conn, current_day, key, children[key][1]),
                                          is_reentry=True)
                    maybe_enforce(conn, current_day, key, children, is_reentry=True,
                                  last_attempts=logoff_attempts)
                previous = (key, unlocked, current_day)
                previous_tick = now
                if user:
                    logging.info('sample user=%s unlocked=%s reason=%s', user, unlocked, reason)
            except Exception:
                # Discard uncertain interval, do not count time when we cannot verify it.
                previous = (None, None, None)
                previous_tick = time.monotonic()
                logging.exception('WTS/SQLite sampling failure')
            time.sleep(poll)




def alert_test():
    if os.name != 'nt' or not ctypes.windll.shell32.IsUserAnAdmin():
        raise RuntimeError('alert-test запускается только в PowerShell администратора')
    user, unlocked, reason = active_console()
    if not user or unlocked is not True:
        raise RuntimeError('Разблокируйте экран для теста: ' + reason)
    print('Пробуем показать уведомление в активной сессии:', user)
    send_notification(user, 'ChildControl — проверка уведомлений',
                      'Это тестовое сообщение. Время не изменяется, '
                      'блокировки нет.', timeout=30)
    print('Windows приняла запрос на отображение уведомления.')
    return 0



def policy_demo():
    """Demonstrate all hypothetical stages without changing settings or DB."""
    sample_limit = 4  # demonstration only: actual configured limit is unchanged
    print('ChildControl 4.3: ТОЛЬКО ИМИТАЦИЯ (данные и лимиты не изменяются)')
    for label, seconds in [
        ('До лимита', 3*60 + 30),
        ('Ровно лимит', 4*60),
        ('Через 30 секунд', 4*60 + 30),
        ('Через 60 секунд', 5*60),
        ('Повторный вход', 5*60 + 1),
    ]:
        decision = decide(seconds, sample_limit)
        print('{}: {}'.format(label, explain(decision)))
        if label == 'Повторный вход' and decision.phase == 'would_sign_out':
            print('ИМИТАЦИЯ: повторный вход был бы отклонён; Windows не затрагивается')
    print('Настоящие выход, блокировка и смена паролей НЕ реализованы в этой версии.')
    return 0


def policy_status():
    children, _ = load_settings()
    today = date.today().isoformat()
    if not DB.exists():
        print('База статистики отсутствует')
        return 0
    with connect_db() as conn:
        for key, (name, limit) in children.items():
            used = usage_today(conn, today, key)
            effective = effective_minutes(conn, today, key, limit)
            outcome = decide(used, effective)
            events = [row[0] for row in conn.execute(
                'SELECT event FROM simulated_actions WHERE day=? AND username=? ORDER BY event',
                (today, key))]
            print('{} | {} | {:.0f} сек из {} сек | {}'.format(
                today, name, used, effective * 60, explain(outcome)))
            print('  События имитации: {}'.format(', '.join(events) or '(нет)'))
    return 0


def main():
    parser = argparse.ArgumentParser(description='ChildControl 4.5: локальный учёт и постоянные родительские ограничения')
    parser.add_argument('command', choices=['probe', 'status', 'run', 'alert-test', 'policy-demo', 'policy-status', 'guard-status', 'guard-preview', 'guard-arm', 'guard-off', 'enforce-status', 'enforce-on', 'enforce-off', 'time-add', 'pause', 'pause-off'])
    parser.add_argument('--user', default=None)
    parser.add_argument('--minutes', type=int, default=10)
    args = parser.parse_args()
    try:
        if args.command == 'probe':
            return probe()
        if args.command == 'status':
            return status()
        if args.command == 'alert-test':
            return alert_test()
        if args.command == 'policy-demo':
            return policy_demo()
        if args.command == 'policy-status':
            return policy_status()
        if args.command == 'guard-status':
            return cli_guard_status()
        if args.command == 'guard-preview':
            return cli_guard_preview()
        if args.command == 'guard-arm':
            return cli_guard_arm(args.user, args.minutes)
        if args.command == 'guard-off':
            return cli_guard_off()
        if args.command == 'enforce-status':
            return cli_enforce_status()
        if args.command == 'enforce-on':
            return cli_enforce_on(args.user)
        if args.command == 'enforce-off':
            return cli_enforce_off(args.user)
        if args.command == 'time-add':
            return cli_add_minutes(args.user, args.minutes)
        if args.command == 'pause':
            return cli_pause(args.user, args.minutes)
        if args.command == 'pause-off':
            return cli_pause_off(args.user)
        return run()
    except (OSError, RuntimeError, ValueError, sqlite3.Error, json.JSONDecodeError) as exc:
        print('ОШИБКА:', exc, file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
