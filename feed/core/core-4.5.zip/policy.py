"""Side-effect-free ChildControl 4.3 policy simulation.

This module NEVER signs users out, locks Windows, changes passwords, or
modifies local accounts.  It only evaluates a proposed policy.
"""
from dataclasses import dataclass

DEFAULT_GRACE_SECONDS = 60


@dataclass(frozen=True)
class Decision:
    phase: str  # allowed | grace | would_sign_out
    limit_seconds: int
    used_seconds: float
    grace_left_seconds: float


def decide(used_seconds, limit_minutes, grace_seconds=DEFAULT_GRACE_SECONDS):
    """Model a daily quota and grace period, with no side effects."""
    if not isinstance(limit_minutes, int) or isinstance(limit_minutes, bool) or not 1 <= limit_minutes <= 1440:
        raise ValueError('limit_minutes must be an integer from 1 to 1440')
    if not isinstance(grace_seconds, int) or isinstance(grace_seconds, bool) or not 0 <= grace_seconds <= 600:
        raise ValueError('grace_seconds must be an integer from 0 to 600')
    if isinstance(used_seconds, bool) or not isinstance(used_seconds, (float, int)) or not (0 <= used_seconds < float('inf')):
        raise ValueError('used_seconds must be nonnegative and finite')
    limit = limit_minutes * 60
    if used_seconds < limit:
        return Decision('allowed', limit, float(used_seconds), float(grace_seconds))
    if used_seconds < limit + grace_seconds:
        return Decision('grace', limit, float(used_seconds), max(0.0, limit + grace_seconds - used_seconds))
    return Decision('would_sign_out', limit, float(used_seconds), 0.0)


def explain(decision):
    if decision.phase == 'allowed':
        remaining = max(0, int(decision.limit_seconds - decision.used_seconds))
        return 'РАЗРЕШЕНО: до лимита ~{} сек'.format(remaining)
    if decision.phase == 'grace':
        return 'ИМИТАЦИЯ: время закончилось, для сохранения работы осталось ~{} сек'.format(
            int(decision.grace_left_seconds))
    return 'ИМИТАЦИЯ: здесь произошёл бы выход из сеанса; реальных действий НЕТ'
